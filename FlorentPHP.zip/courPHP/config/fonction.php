<?php 

echo "Config Fonction importxé";
function Bprint($text,$color) {
    echo '<p class="beautifullPrint">'.$text.'</p>';
}

echo "Config Fonction importé";
function Sprint($text) {
    echo $text.'<br>';
}







?>